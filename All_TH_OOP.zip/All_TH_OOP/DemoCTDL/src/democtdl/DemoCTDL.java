/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package democtdl;

import java.util.Scanner;

/**
 *
 * @author thao trang
 */
public class DemoCTDL {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        static class Node {
        int info;
        Node link;
    }

    static Node first;

    static void init() {
        first = null;
    }

    static void processList() {
        Node p;
        p = first;
        while (p != null) {
            System.out.print(p.info + " ");
            p = p.link;
        }
        System.out.println();
    }

    static Node search(int x) {
        Node p = first;
        while (p != null && p.info != x) {
            p = p.link;
        }
        return p;
    }

    static void insertFirst(int x) {
        Node p = new Node();
        p.info = x;
        p.link = first;
        first = p;
    }

    static int deleteFirst() {
        if (first != null) {
            Node p = first;
            first = first.link;
            return 1;
        }
        return 0;
    }

    static void insertLast(int x) {
        Node p = new Node();
        p.info = x;
        p.link = null;
        if (first != null) {
            Node q = first;
            while (q.link != null) {
                q = q.link;
            }
            q.link = p;
        } else
            first = p;
    }

    static int deleteLast() {
        if (first != null) {
            Node p, q;
            p = first;
            q = first;
            while (p.link != null) {
                q = p;
                p = p.link;
            }
            if (p != first) {
                q.link = null;
            } else
                first = null;
            return 1;
        }
        return 0;
    }

    static int searchDelete(int x) {
        if (first != null) {
            Node q, p;
            p = first;
            q = first;
            while (p.link != null && p.info != x) {
                q = p;
                p = p.link;
            }

            if (p != first && p.link != null) {
                if (p.link != null)
                    q.link = p.link;
                else
                    q.link = null;
                return 1;
            } else if (p == first) {
                first = p.link;
                return 1;
            } else if (p.link == null && p.info == x) {
                q.link = null;
                return 1;
            } else
                return 0;
        }
        return 0;
    }

    static void swap(Node a, Node b) {
        int t = a.info;
        a.info = b.info;
        b.info = t;
    }

    static void sort() {
        Node p, q, min;
        p = first;
        while (p != null) {
            min = p;
            q = p.link;
            while (q != null) {
                if (q.info < min.info)
                    min = q;
                q = q.link;
            }
            swap(min, p);
            p = p.link;
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int choice = 0;
        int x, i = 0;
        Node p;
        init();
        System.out.println("===== BAI TAP 3 - CHUONG 2 - DSLK DON =====");
        System.out.println("(1) Khoi tao DSLK don");
        System.out.println("(2) Them ptu vao dau DSLK don");
        System.out.println("(3) Them ptu vao cuoi DSLK don");
        System.out.println("(4) Xoa ptu dau DSLK don");
        System.out.println("(5) Xoa ptu cuoi DSLK don");
        System.out.println("(6) Xuat DSLK don");
        System.out.println("(7) Tim ptu co gia tri x trong DSLK don");
        System.out.println("(8) Tim ptu co gia tri x trong DSLK don, neu thay thi xoa");
        System.out.println("(9) Sap xep DSLK don tang dan");
        System.out.println("(10) Thoat");

        do {
            System.out.print("\n>> Vui long nhap so: ");
            choice = scanner.nextInt();
            switch (choice) {
                case 1: {
                    init();
                    System.out.println("Khoi tao DSLK thanh cong!!");
                }
                case 2: {
                    System.out.print("Vui long nhap x: ");
                    x = scanner.nextInt();
                    insertFirst(x);
                    System.out.print("DS sau khi them DAU la: ");
                    processList();
                }
                case 3: {
                    System.out.print("Vui long nhap x: ");
                    x = scanner.nextInt();
                    insertLast(x);
                    System.out.print("DS sau khi them CUOI la: ");
                    processList();
                }
                case 4: {
                    i = deleteFirst();
                    if (i == 0)
                        System.out.println("DS rong, khong co gi de xoa!!");
                    else {
                        System.out.println("Da xoa thanh cong ptu DAU!");
                        System.out.print("DS sau khi xoa DAU la: ");
                        processList();
                    }
                }
                case 5: {
                    i = deleteLast();
                    if (i == 0)
                        System.out.println("DS rong, khong co gi de xoa!!");
                    else {
                        System.out.println("Da xoa thanh cong ptu CUOI!");
                        System.out.print("DS sau khi xoa CUOI la: ");
                        processList();
                    }
                }
                case 6: {
                    System.out.print("DS hien tai la: ");
                    processList();
                }
                case 7: {
                    System.out.print("Vui long nhap x: ");
                    x = scanner.nextInt();
                    p = search(x);
                    if (p != null)
                        System.out.println("Tim thay x = " + x + " trong DSLK don!!");
                    else
                        System.out.println("Tim khong thay x!!");
                }
                case 8: {
                    System.out.print("Vui long nhap x: ");
                    x = scanner.nextInt();
                    i = searchDelete(x);
                    if (i == 1) {
                        System.out.println("Tim thay x = " + x + " trong DSLK don!!");
                        System.out.print("Xoa x thanh cong, DSLK sau khi xoa x: ");
                        processList();
                    } else
                        System.out.println("Tim khong thay x !!");
                }
                case 9: {
                    sort();
                    System.out.println("DSLK Don sau khi sap xep tang dan: ");
                    processList();
                }
                case 10: System.out.println("Goodbye!");
                default: {
                }
            }
        } while (choice != 10);
        scanner.close();
    }
}


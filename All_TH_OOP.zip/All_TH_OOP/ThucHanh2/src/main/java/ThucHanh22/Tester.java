/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ThucHanh22;

/**
 *
 * @author thao trang
 */
public class Tester {
    public static void main(String[] args) {
        PhanSo p1 = new PhanSo(1,3);
        PhanSo p1 = new PhanSo(4,3);
        PhanSo p1 = new PhanSo(1,3);
    }
}

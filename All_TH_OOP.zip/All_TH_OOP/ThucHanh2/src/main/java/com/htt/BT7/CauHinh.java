/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.htt.BT7;

/**
 *
 * @author thao trang
 */
public class CauHinh {
    public static final String DATE_FORMAT = "dd/MM/yyyy";
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.htt.BT7;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author thao trang
 */
public class HocVien {
    private static int dem;
    private int maSV = ++dem;
    private String tenHv;
    private LocalDate ngaySinh;
    private double[] diem;
    
    public HocVien(String tenHv, LocalDate ngaySinh){
        this.tenHv = tenHv;
        this.ngaySinh = ngaySinh;
    }
    public HocVien(String tenHv, String ngaySinh){
        //thay dd/MM/yyyy tách thành 1 class mới chỉ tạo 1 lần và gọi lại sài
        this(tenHv, LocalDate.parse(ngaySinh, DateTimeFormatter.ofPattern(CauHinh.DATE_FORMAT)));
    }

    public void hienThi(){
        System.out.printf("Ma hoc vien: %d\nTen hoc vien: %s\n Ngay sinh: %s\n", 
                this.maSV, this.tenHv, 
                this.ngaySinh.format(DateTimeFormatter.ofPattern(CauHinh.DATE_FORMAT)));
    }
    
//    public void nhap1Hv(){
//        System.out.print("Ho ten: ");
//        this.tenHv = 
//    }
//    public void nhapDiem1Hv(){
//        this.diem = new double[];
//        for ()
//    }
    /**
     * @return the maSV
     */
    public int getMaSV() {
        return maSV;
    }

    /**
     * @param maSV the maSV to set
     */
    public void setMaSV(int maSV) {
        this.maSV = maSV;
    }

    /**
     * @return the tenHv
     */
    public String getTenHv() {
        return tenHv;
    }

    /**
     * @param tenHv the tenHv to set
     */
    public void setTenHv(String tenHv) {
        this.tenHv = tenHv;
    }
    
}

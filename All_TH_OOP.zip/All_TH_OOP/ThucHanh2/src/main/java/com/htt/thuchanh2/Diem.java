/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.htt.thuchanh2;

/**
 *
 * @author thao trang
 */
public class Diem {
    private double hoanhDo;
    private double tungDo;
    
    //Phương thức khởi tạo
    public Diem(double hoanhDo, double tungDo){
        this.hoanhDo = hoanhDo;
        this.tungDo = tungDo;
    }
    
    public void hienThi(){
        System.out.printf("(%.1f, %.1f)", this.hoanhDo, this.tungDo);
    }
    
     //Tính khoảng cách
    public double tinhKhoangCach(Diem d){
        return Math.sqrt(Math.pow(this.hoanhDo - d.hoanhDo,2) + Math.pow(this.tungDo - d.tungDo, 2));
    }
    
    //phương thức getter and setter
    public double getHoanhDo(){
        return hoanhDo;
    }
    public void setHoanhDo(double hoanhDo) {
        this.hoanhDo = hoanhDo;
    }
    
    public double getTungDo() {
        return tungDo;
    }
    
    public void setTungDo(double tungDo){
        this.tungDo = tungDo;
    }
    
   
    
    
}

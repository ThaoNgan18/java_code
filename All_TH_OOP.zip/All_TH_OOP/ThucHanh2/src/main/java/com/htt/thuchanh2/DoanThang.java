/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.htt.thuchanh2;

/**
 *
 * @author thao trang
 */
public class DoanThang {
    private Diem diemDau;
    private Diem diemCuoi;
    
    
    public DoanThang(Diem diemDau, Diem diemCuoi){
        this.diemDau = diemDau;
        this.diemCuoi = diemCuoi;
    }
    
    public void hienThi(){
        System.out.printf("((%.1f, %.1f), (%.1f, %.1f)", 
                this.getDiemDau().getHoanhDo(), this.getDiemDau().getTungDo(),
                this.getDiemCuoi().getHoanhDo(), this.getDiemCuoi().getTungDo());
    }
    
//    public Diem tinhDoDai(){
//        return this.getDiem
//        return this.getDiemDau().tinhKhoangCach(this.getDiemCuoi());
//    }
//    
    public Diem tinhTrungDiem(){
        double x = (this.getDiemDau().getHoanhDo() + this.getDiemCuoi().getHoanhDo())/2;
        double y = (this.getDiemDau().getTungDo() + this.getDiemCuoi().getTungDo())/2;
        
        Diem d = new Diem(x,y);
        return d;
    }
    
    public boolean isSongSong(DoanThang dt){
        double v1 = (this.diemDau.getHoanhDo() - this.diemCuoi.getHoanhDo()) * (dt.diemDau.getTungDo() - dt.diemCuoi.getTungDo());
        double v2 = (this.diemDau.getTungDo() - this.diemCuoi.getTungDo() * (dt.diemDau.getHoanhDo() - dt.diemCuoi.getHoanhDo()));
        
        return v1 == v2;
    }

    /**
     * @return the diemDau
     */
    public Diem getDiemDau() {
        return diemDau;
    }

    /**
     * @param diemDau the diemDau to set
     */
    public void setDiemDau(Diem diemDau) {
        this.diemDau = diemDau;
    }

    /**
     * @return the diemCuoi
     */
    public Diem getDiemCuoi() {
        return diemCuoi;
    }

    /**
     * @param diemCuoi the diemCuoi to set
     */
    public void setDiemCuoi(Diem diemCuoi) {
        this.diemCuoi = diemCuoi;
    }
}

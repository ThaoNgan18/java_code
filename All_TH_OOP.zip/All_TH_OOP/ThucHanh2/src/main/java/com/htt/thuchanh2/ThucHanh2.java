/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.htt.thuchanh2;

/**
 *
 * @author thao trang
 */
public class ThucHanh2 {

    public static void main(String[] args) {
        Diem d1 = new Diem(5,9);
        Diem d2 = new Diem(-7, 4);
        
        d1.hienThi();
        d2.hienThi();
        
        double kc = d1.tinhKhoangCach(d2);
        System.out.printf("Khoang cach = %.1f\n", kc);
    }
}

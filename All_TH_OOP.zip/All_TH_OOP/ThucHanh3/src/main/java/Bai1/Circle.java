/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bai1;

/**
 *
 * @author thao trang
 */
public class Circle extends Ellipse{
    public Circle(double bk){
        super(bk,bk);
    }

    //dễ bị trùng nên tách ra
//    @Override
//    public void hienThi() {
//        System.out.printf("Hinh Circle\nDien Tich: %.1f\n",this.tinhDienTich());
//    }

    @Override
    public String layTenHinh() {
        return "Hinh Circle";
    }
    
    
}

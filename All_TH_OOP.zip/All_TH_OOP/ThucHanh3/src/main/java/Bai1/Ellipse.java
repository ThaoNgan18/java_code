/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bai1;

/**
 *
 * @author thao trang
 */
public class Ellipse extends Hinh{
    private double bkTrucLon;
    private double bkTrucBe;

    //cons có tham số
    public Ellipse(double bkTrucLon, double bkTrucBe){
        this.bkTrucLon = bkTrucLon;
        this.bkTrucBe = bkTrucBe;
    }
    
    public double tinhDienTich(){
        return Math.PI * this.bkTrucLon * this.bkTrucBe;
    }
    
    public double tinhChuVi(){
        return Math.PI * 2 * Math.sqrt((Math.pow(bkTrucLon,2) + Math.pow(bkTrucBe,2) )/ 2);
    }
    
    public String layTenHinh(){
        return "Hinh Ellipse";
    }
    public void hienThi(){
        System.out.printf("%s\nDien Tich: %.1f\n",this.layTenHinh(),this.tinhDienTich());
        System.out.printf("%s\nChu Vi: %.1f\n",this.layTenHinh(),this.tinhChuVi());
    }
    
    /**
     * @return the bkTrucLon
     */
    public double getBkTrucLon() {
        return bkTrucLon;
    }

    /**
     * @param bkTrucLon the bkTrucLon to set
     */
    public void setBkTrucLon(double bkTrucLon) {
        this.bkTrucLon = bkTrucLon;
    }

    /**
     * @return the btTrucBe
     */
    public double getBtTrucBe() {
        return bkTrucBe;
    }

    /**
     * @param bkTrucBe the btTrucBe to set
     */
    public void setBtTrucBe(double bkTrucBe) {
        this.bkTrucBe = bkTrucBe;
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bai1;

import java.util.Arrays;

/**
 *
 * @author thao trang
 */
public class main {

    public static void main(String[] args) throws Exception {
        Ellipse e1 = new Ellipse(56, 50);
        Ellipse e2 = new Circle(55);

        TamGiac t1 = new TamGiacCan(60, 50);
        TamGiac t2 = new TamGiacDeu(56);
        TamGiac t3 = new TamGiacCan(5, 5);

//        e1.hienThi();
//        e2.hienThi();
//        t1.hienThi();
//        t2.hienThi();
//        t3.hienThi();
        Hinh[] a = {e1, e2, t1, t2, t3};

//        Arrays.sort(a, (h1, h2) -> {
//            double t11 = h1.tinhDienTich();
//            double t22 = h2.tinhDienTich();
//
//            if (t11 > t22) {
//                return -1;
//            } else if (t11 < t22) {
//                return 1;
//            }
//            return 0;
//        });

        Arrays.sort(a, (h1, h2) -> {
            String ten1 = h1.layTenHinh();
            String ten2 = h2.layTenHinh();

            if (ten1.equals(ten2) == true) {
                double t11 = h1.tinhDienTich();
                double t22 = h2.tinhDienTich();

                if (t11 > t22) {
                    return -1;
                } else if (t11 < t22) {
                    return 1;
                }
                return 0;
            }
            return ten1.compareTo(ten2);
        });
        for (var x : a) {
            x.hienThi();
        }

        //mảng chứa 4 đối tượng
        //a sắp xếp ds giảm dần theo dien tich
        //b sap xep tang dan the ten, neu cùng ten thi giam dan theo dien tich
    }
}

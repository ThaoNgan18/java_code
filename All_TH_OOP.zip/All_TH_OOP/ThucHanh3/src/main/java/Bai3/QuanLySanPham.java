/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bai3;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author thao trang
 */
public class QuanLySanPham {

    private List<SanPham> ds = new ArrayList<>();

    public void themSp(SanPham s) {
        this.ds.add(s);
    }
    public void hienThi() {
        this.ds.forEach(s -> s.hienThi());
    }
    
    public SanPham traCuu(int id) {
        return this.ds.stream().filter(s -> s.getId() == id).findFirst().get();
    }

//    public List<SanPham> traCuu(String tuKhoa) {
//        return this.ds.stream().filter(s -> s.getTenSp().contains(tuKhoa)).collect(Collectors.toList());
//    }
//
//    public List<SanPham> traCuu(double tuGia, double denGia) {
//        return this.ds.stream().filter(s -> s.getGia() >= tuGia && s.getGia() <= denGia).collect(Collectors.toList());
//    }
    
    /**
     * @return the ds
     */
    public List<SanPham> getDs() {
        return ds;
    }

    /**
     * @param ds the ds to set
     */
    public void setDs(List<SanPham> ds) {
        this.ds = ds;
    }
}

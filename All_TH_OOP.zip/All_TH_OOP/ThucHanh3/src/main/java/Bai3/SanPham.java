/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bai3;

/**
 *
 * @author thao trang
 */
public class SanPham {
    private static int dem = 0;
    private int id = ++dem;
    private String tenSp;
    private double gia;

    //cons rõng
    public SanPham(){
        
    }
    
    public SanPham(String tenSp, double gia) {
        this.tenSp = tenSp;
        this.gia = gia;
    }
    
    public void hienThi() {
        System.out.printf("Ma Sp: %d\nTen: %s\nGia: %.1f\n",
                this.id, this.tenSp, this.gia);
    }

    public void nhap1Sp(){
        System.out.print("Ten sp = ");
        this.tenSp = CauHinh.sc.nextLine();
        System.out.println("gia sp: ");
        this.gia = Double.parseDouble(CauHinh.sc.nextLine());
    }
    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the tenSp
     */
    public String getTenSp() {
        return tenSp;
    }

    /**
     * @param tenSp the tenSp to set
     */
    public void setTenSp(String tenSp) {
        this.tenSp = tenSp;
    }

    /**
     * @return the gia
     */
    public double getGia() {
        return gia;
    }

    /**
     * @param gia the gia to set
     */
    public void setGia(double gia) {
        this.gia = gia;
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bai3;

/**
 *
 * @author thao trang
 */
public class Test {
    public static void main(String[] args) {
        SanPham s2 = new Sach("Lap trinh huong doi tuong",20000,100);
        SanPham s3 = new Sach("Co so lap trinh", 10000, 800);
        SanPham s4 = new BangDia("Gioi thieu OU IT", 15000, 30);
        
        QuanLySanPham ql = new QuanLySanPham();
        ql.themSp(s2);
        ql.themSp(s3);
        ql.themSp(s4);
        
       
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package Bai4;

import java.time.LocalDate;

/**
 *
 * @author thao trang
 */
public enum KyHan {
    MOT_TUAN(7,0.5){
        @Override
        public LocalDate tinhDaoHan(LocalDate d) {
          return d.plusDays(this.khoangTime);
        }

        @Override
        public double tinhLai(double st) {
          return (st*this.laiSuat)/100/12/4;
        }
        
    }, 
    MOT_THANG(1, 4.5){
        @Override
        public LocalDate tinhDaoHan(LocalDate d) {
             return d.plusMonths(this.khoangTime);
        }

        @Override
        public double tinhLai(double st) {
           return (st*this.laiSuat)/100/12;
        }
        
    };
    protected int khoangTime;
    protected double laiSuat;
    
    
    private KyHan(int khoangTime, double ls){
        this.khoangTime = khoangTime;
        this.laiSuat = ls;
    }
    


    public abstract LocalDate tinhDaoHan(LocalDate d);
    public abstract double tinhLai(double st);
}

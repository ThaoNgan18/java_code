/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bai4;

/**
 *
 * @author thao trang
 */
public class Tester {
    public static void main(String[] args) {
        TaiKhoan t1 = new TaiKhoan("nguyen van a",5000);
        TaiKhoan t2 = new TaiKhoanKyHan("Tran Thi B", 10000, KyHan.MOT_TUAN);
        TaiKhoan t3 = new TaiKhoanKyHan("Ngueyn Van C", 500000, KyHan.MOT_THANG);
        
        t1.hienThi();
        t2.hienThi();
        t3.hienThi();
    }
    
}

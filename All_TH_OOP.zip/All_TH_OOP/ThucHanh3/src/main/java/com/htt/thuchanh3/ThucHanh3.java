/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.htt.thuchanh3;

/**
 *
 * @author thao trang
 */
public class ThucHanh3 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.btl.tracnghiemta;

import static com.btl.tracnghiemta.CauHinh.sc;
import java.util.List;
import java.util.Objects;

/**
 *
 * @author thao trang
 */
public abstract class CauHoi {

    private static int dem = 0;
    private final int maCauHoi;
    private String capDo;
    private DanhMuc danhMuc;
    private String noiDung;

    {
        dem++;
        this.maCauHoi = dem;
    }

    public CauHoi() {
    }

//    public CauHoi(String noiDung) {
//        this.noiDung = noiDung;
//    }
//
//    public CauHoi(String noiDung, int doKho) {
//        this(noiDung);
//        this.capDo = doKho;
//    }
    /**
     *
     * @param danhMuc
     * @param noiDung
     * @param capDo
     */
    public CauHoi(String capDo, DanhMuc danhMuc, String noiDung) {
        this.capDo = capDo;
        this.danhMuc = danhMuc;
        this.noiDung = noiDung;
    }

    public void nhapThongTinCauHoi() {
        System.out.print("Muc Do (0:De, 1:Trung binh, 2:Kho):");
        this.capDo = CauHinh.sc.nextLine();
        System.out.print("Noi dung cau hoi: ");
        this.noiDung = CauHinh.sc.nextLine();
    }

    public void hienThiThongTin() {
        System.out.printf("\n----THONG TIN CAU HOI %d ----\n", maCauHoi);
        System.out.printf("- Muc do: %s\t\t", capDo);
        System.out.printf("- Danh muc: %s\n", danhMuc.getTenDanhMuc());
        System.out.printf("- Noi dung: %s\n", noiDung);
    }

    @Override
    public String toString() {
        return String.format("%s"
                + "\t%-20s"
                + "\t%-20s"
                + "\t%-20s\n", this.getMaCauHoi(), this.getCapDo(), this.getDanhMuc(), this.getNoiDung());
    }

    public abstract List<MultipleChoice> getdsCauHoi();
//    public void addChoice(PhuongAn c) {}
//    public void hienThi() {}

    /**
     * @return the maCauHoi
     */
    public int getMaCauHoi() {
        return maCauHoi;
    }

    /**
     * @return the danhMuc
     */
    public DanhMuc getDanhMuc() {
        return danhMuc;
    }

    /**
     * @param danhMuc the danhMuc to set
     */
    public void setDanhMuc(DanhMuc danhMuc) {
        this.danhMuc = danhMuc;
    }

    /**
     * @return the noiDung
     */
    public String getNoiDung() {
        return noiDung;
    }

    /**
     * @param noiDung the noiDung to set
     */
    public void setNoiDung(String noiDung) {
        this.noiDung = noiDung;
    }

    /**
     * @return the capDo
     */
    public String getCapDo() {
        return capDo;
    }

    /**
     * @param capDo the capDo to set
     */
    public void setCapDo(String capDo) {
        this.capDo = capDo;
    }

}

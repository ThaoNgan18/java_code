/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.btl.tracnghiemta;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author thao trang
 */
public class Conversation extends CauHoi {

    private List<MultipleChoice> dsCauHoi = new ArrayList<>();


    public Conversation() {
    }

    public Conversation(String capDo, String noiDung, DanhMuc danhMuc) {
        super(capDo, danhMuc, noiDung);
        this.dsCauHoi = dsCauHoi;
    }
//    public void hienThi() {
//        System.out.println(this.getNoiDung());
//        for (int i = 0; i < this.getDsCauHoi().size(); i++) {
//            System.out.printf("\nCau hoi so %d: ", i + 1);
//            this.getDsCauHoi().get(i).hienThi();
//        }
//    }
//
//    @Override
//    public String toString() {
//        String s = super.toString(); //To change body of generated methods, choose Tools | Templates.
//
//        for (MultipleChoice q : this.getDsCauHoi()) {
//            s += q;
//        }
//        return s;
//    }

    /**
     * @return the dsCauHoi
     */
    @Override
    public List<MultipleChoice> getdsCauHoi() {
        return dsCauHoi;
    }

    /**
     * @param dsCauHoi the dsCauHoi to set
     */
    public void setDsCauHoi(List<MultipleChoice> dsCauHoi) {
        this.dsCauHoi = dsCauHoi;
    }

    

}

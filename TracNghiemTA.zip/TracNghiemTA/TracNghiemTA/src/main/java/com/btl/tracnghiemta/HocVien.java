/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.btl.tracnghiemta;

import com.btl.main.main;
import static com.btl.tracnghiemta.CauHinh.c;
import static com.btl.tracnghiemta.CauHinh.f;
import static com.btl.tracnghiemta.CauHinh.sc;
import java.io.File;
//import java.io.FileNotFoundException;
import java.text.ParseException;
import java.util.Date;
import java.util.Objects;
import java.util.Scanner;

/**
 *
 * @author thao trang
 */
public class HocVien {

    private static int dem = 0;
    private int maHocVien;
    private String hoTen;
    private Date ngaySinh;
    private Date ngayGiaNhap;
    private String gioiTinh;
    private String queQuan;
    private ThanhTich thanhTich;

    private static CheckData check = new CheckData();

    {
       ngayGiaNhap = c.getTime();
       dem++;
       maHocVien = dem;
    }

    public HocVien() {

    }

    public HocVien(String hoTen, Date ngaySinh, String gioiTinh, String queQuan) {
        this.hoTen = hoTen;
        this.ngaySinh = ngaySinh;
        this.gioiTinh = gioiTinh;
        this.queQuan = queQuan;
        
    }

    public HocVien(String hoTen, Date ngaySinh, String gioiTinh, String queQuan, Date ngayGiaNhap,ThanhTich thanhTich) {
        this.hoTen = hoTen;
        this.ngaySinh = ngaySinh;
        this.gioiTinh = gioiTinh;
        this.queQuan = queQuan;
        this.ngayGiaNhap = ngayGiaNhap;
        this.thanhTich = thanhTich;
    }

//    public HocVien(String hoTen, String queQuan, String gioiTinh, Date ngaySinh) throws ParseException {
//        this(hoTen, queQuan, gioiTinh, f.parse(ngaySinh));
//    }
    @Override
    public String toString() {
        return String.format("%d"
                + "\t%-20s"
                + "\t%-15s"
                + "\t%-15s"
                + "\t%-15s"
                + "\t%-15s", this.getMaHocVien(), check.chuanHoa(this.getHoTen()), check.chuanHoa(this.getGioiTinh()),
                check.chuanHoa(this.getQueQuan()), check.xuatNgayThangNam(this.getNgaySinh()), check.xuatNgayThangNam(this.getNgayGiaNhap()));
    }

    public void nhapThongTin() throws ParseException {
        System.out.println(" ");
        System.out.print("Ho Ten: ");
        this.setHoTen(CauHinh.sc.nextLine());

        System.out.print("Gioi Tinh: ");
        this.setGioiTinh(CauHinh.sc.nextLine());

        System.out.print("Ngay Sinh (dd/MM/yyyy): ");
        this.setNgaySinh(check.nhapNgayThangNam(CauHinh.sc.nextLine()));

        System.out.print("Que Quan: ");
        this.setQueQuan(CauHinh.sc.nextLine());

    }

    /**
     * @return the dem
     */
    public static int getDem() {
        return dem;
    }

    /**
     * @param aDem the dem to set
     */
    public static void setDem(int aDem) {
        dem = aDem;
    }

    /**
     * @return the maHocVien
     */
    public int getMaHocVien() {
        return maHocVien;
    }
    
    /**
     * @return the hoTen
     */
    public String getHoTen() {
        return hoTen;
    }

    /**
     * @param hoTen the hoTen to set
     */
    public void setHoTen(String hoTen) {
        this.hoTen = hoTen;
    }

    /**
     * @return the ngaySinh
     */
    public Date getNgaySinh() {
        return ngaySinh;
    }

    /**
     * @param ngaySinh the ngaySinh to set
     */
    public void setNgaySinh(Date ngaySinh) {
        this.ngaySinh = ngaySinh;
    }

    /**
     * @return the ngayGiaNhap
     */
    public Date getNgayGiaNhap() {
        return ngayGiaNhap;
    }

    /**
     * @param ngayGiaNhap the ngayGiaNhap to set
     */
    public void setNgayGiaNhap(Date ngayGiaNhap) {
        this.ngayGiaNhap = ngayGiaNhap;
    }

    /**
     * @return the gioiTinh
     */
    public String getGioiTinh() {
        return gioiTinh;
    }

    /**
     * @param gioiTinh the gioiTinh to set
     */
    public void setGioiTinh(String gioiTinh) {
        this.gioiTinh = gioiTinh;
    }

    /**
     * @return the queQuan
     */
    public String getQueQuan() {
        return queQuan;
    }

    /**
     * @param queQuan the queQuan to set
     */
    public void setQueQuan(String queQuan) {
        this.queQuan = queQuan;
    }

    /**
     * @return the thanhTich
     */
    public ThanhTich getThanhTich() {
        return thanhTich;
    }

    /**
     * @param thanhTich the thanhTich to set
     */
    public void setThanhTich(ThanhTich thanhTich) {
        this.thanhTich = thanhTich;
    }
    
       //kiểm tra
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        HocVien hv = (HocVien) obj; //ép kiểu đối tượng obj thành Học viên
        return getMaHocVien() == hv.getMaHocVien();
    }

    @Override
    public int hashCode() {
        return Objects.hash(getMaHocVien());
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.btl.tracnghiemta;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author thao trang
 */
public class InComplete extends CauHoi {

    private List<MultipleChoice> dsCauHoi = new ArrayList<>();
//    private int doKho;

    public InComplete() {
    }

    public InComplete(String capDo, String noiDung, DanhMuc danhMuc) {
        super(capDo, danhMuc, noiDung);
        this.dsCauHoi = dsCauHoi;
    }

//    @Override
//    public void hienThi() {
//        System.out.println(this.getNoiDung());
//        for (int i = 0; i < this.getDsCauHoi().size(); i++) {
//            System.out.printf("\nTra loi cau hoi so %d: ", i + 1);
//            this.getDsCauHoi().get(i).hienThi();
//        }
//    }

//    @Override
//    public String toString() {
//        String s = super.toString();
//
//        for (MultipleChoice q : this.getDsCauHoi()) {
//            s += q;
//        }
//        return s;
//    }

    /**
     * @param dsCauHoi the dsCauHoi to set
     */
    public void setDsCauHoi(List<MultipleChoice> dsCauHoi) {
        this.dsCauHoi = dsCauHoi;
    }

    @Override
    public List<MultipleChoice> getdsCauHoi() {
        return dsCauHoi;
    }

}

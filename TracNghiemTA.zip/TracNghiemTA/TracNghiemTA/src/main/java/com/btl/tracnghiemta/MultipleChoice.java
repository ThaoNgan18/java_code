/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.btl.tracnghiemta;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author thao trang
 */
public class MultipleChoice extends CauHoi {

    private static final String[] LABELS = {"A", "B", "C", "D"};
    private List<PhuongAn> dsPhuongAn = new ArrayList<>();

    public MultipleChoice() {

    }

    public MultipleChoice(String capDo, String noiDung, DanhMuc danhMuc) {
        super(capDo, danhMuc, noiDung);
        this.dsPhuongAn = dsPhuongAn;
    }

    public void hienThiDsPhuongAn() {
        System.out.println(this.LABELS);
        for (int i = 0; i < this.getDsPhuongAn().size(); i++) {
            System.out.println(this.getDsPhuongAn().get(i));
        }
    }

//    public void xuatDsPhuongAn() {
//        System.out.println(this.LABELS);
//        for (PhuongAn pa : this.getDsPhuongAn()) {
//            System.out.println(pa);
//        }
//    }

    /**
     * @return the dsPhuongAn
     */
    public List<PhuongAn> getDsPhuongAn() {
        return dsPhuongAn;
    }

    /**
     * @param dsPhuongAn the dsPhuongAn to set
     */
    public void setDsPhuongAn(List<PhuongAn> dsPhuongAn) {
        this.dsPhuongAn = dsPhuongAn;
    }

    @Override
    public List<MultipleChoice> getdsCauHoi() {
        return null;
    }
}

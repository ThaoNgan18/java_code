/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.btl.tracnghiemta;

import java.security.interfaces.DSAParams;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;
import java.text.ParseException;
import java.util.function.Predicate;

/**
 *
 * @author thao trang
 */
public class QuanLyCauHoi {

    private List<CauHoi> dsCauHoi = new ArrayList<>();
    private String LABEL = String.format("%s\t%-20s\t%-20s\t%-20s",
            "ID", "Muc Do", "Danh Muc", "Noi Dung");

    public static int random(int min, int max) {
        Random random = new Random();
//        return random.nextInt((max - min) + 1) + min;
        return (int)(Math.random() * (max - min + 1) + min);
    }

    public static List<MultipleChoice> nhapDsMultipleChoice(int soLuong) {
        List<MultipleChoice> dsCauHoi = new ArrayList<>();
        for (int i = 0; i < soLuong; i++) {
            MultipleChoice cauHoi = new MultipleChoice();
            cauHoi.nhapThongTinCauHoi();
            System.out.print("Nhap so luong phuong an: ");
            int soLuongPA = Integer.parseInt(CauHinh.sc.nextLine());
            List<PhuongAn> dsPhuongAn = PhuongAn.nhapDsPhuongAn(soLuongPA);
            cauHoi.setDsPhuongAn(dsPhuongAn);
            dsCauHoi.add(cauHoi);
        }
        return dsCauHoi;
    }

    public void themCauHoi(CauHoi... dsCauHoi) {
        this.dsCauHoi.addAll(Arrays.asList(dsCauHoi));
    }

    public void xoaCauHoi(CauHoi... dsCauHoi) {
        this.dsCauHoi.removeAll(Arrays.asList(dsCauHoi));
    }

    public void hienThiDS() {
        System.out.println(LABEL);
        for (CauHoi ch : dsCauHoi) {
            System.out.println(ch);
        }
    }

    public void hienThiDS(List<CauHoi> ds) {
        System.out.println(LABEL);
        for (CauHoi cauHoi : ds) {
            System.out.println(cauHoi);
        }
    }

    /**
     * Tra cuu theo ma Cau Hoi (Xoa cau hoi
     *
     * @param maCauHoi
     * @return tra ra 1 cau hoi can tim
     */
    public CauHoi traCuuTheoId(int maCauHoi) {
        return this.getDsCauHoi().stream().filter(cauHoi -> cauHoi.getMaCauHoi() == maCauHoi).findFirst().orElse(null);
    }
    
    /**
     * Tìm kiếm câu hỏi theo nội dung hoặc mức độ
     *
     * @param tuKhoa Nội dung, mức độ
     * @return Danh sách câu hoi thỏa điều kiện
     */
    public List<CauHoi> traCuu(String tuKhoa) {
        return this.getDsCauHoi().stream()
                .filter(cauHoi -> cauHoi.getNoiDung().equalsIgnoreCase(tuKhoa) || cauHoi.getCapDo().equalsIgnoreCase(tuKhoa))
                .collect(Collectors.toList());
    }

    public CauHoi randomCauHoi(String type, String capDo) throws ClassNotFoundException {
        Class c = Class.forName(type);
        List<CauHoi> ds = this.getDsCauHoi().stream()
                .filter(cauHoi -> c.isInstance(cauHoi) && cauHoi.getCapDo().equals(capDo)).collect(Collectors.toList());
        return ds.get(random(0, ds.size() - 1));
    }
    
    public List<CauHoi> randomCauHoi(String type, int soLuong) throws ClassNotFoundException {
        List<CauHoi> ds = new ArrayList<>();
        Class c = Class.forName(type);
        for (int i = 0; i < soLuong; i++) {
            CauHoi cauHoi = this.getDsCauHoi().get(random(0, this.getDsCauHoi().size() - 1));
            if (c.isInstance(cauHoi) && !ds.contains(cauHoi)) {
                ds.add(cauHoi);
            }
        }
        return ds;
    }

  
    public List<CauHoi> getDsCauHoi() {
        return dsCauHoi;
    }

    private Object dsCauHoi() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    /**
     * @param dsCauHoi the dsCauHoi to set
     */
    //public void setDsCauHoi(List<CauHoi> dsCauHoi) {
    //    this.dsCauHoi = dsCauHoi;
    //}
//    public QuanLyCauHoi() {
//        this.cauhoi = new ArrayList<>();
//    }
//
//    public void themCauHoi(CauHoi q) {
//        this.getCauhoi().add(q);
//    }
//
//
//    public void xuatNoiDung() {
//        for (int i = 0; i < this.cauhoi.size(); i++) {
//            System.out.printf("%d) %s\n", i + 1, this.cauhoi.get(i).getNoiDung());
//        }
//
//    }
//
//    public QuanLyCauHoi traCuuTheoDoKho(int doKho) {
//        QuanLyCauHoi result = new QuanLyCauHoi();
//        for (CauHoi cauHoi : cauhoi) {
//            if (cauHoi.getCapDo() == doKho) {
//                result.themCauHoi(cauHoi);
//            }
//        }
//
//        return result;
//    }
//
//    public QuanLyCauHoi traCuuTheoNoiDung(String nd) {
//        QuanLyCauHoi result = new QuanLyCauHoi();
//
//        for (CauHoi cauHoi : cauhoi) {
//            if (cauHoi.getNoiDung().toLowerCase().contains(nd.toLowerCase())) {
//                result.themCauHoi(cauHoi);
//            }
//        }
//
//        return result;
//    }
//
//    public QuanLyCauHoi traCuuTheoDanhMuc(String danhMuc) {
//        QuanLyCauHoi result = new QuanLyCauHoi();
//
//        for (CauHoi cauHoi : cauhoi) {
//            if (cauHoi.getDanhMuc().toLowerCase().contains(danhMuc.toLowerCase())) {
//                result.themCauHoi(cauHoi);
//            }
//        }
//
//        return result;
//    }
//
//    public QuanLyCauHoi danhSachTheoMultipleChoice(int n) {
//        QuanLyCauHoi result = new QuanLyCauHoi();
//        int dem = 0;
//
//        for (CauHoi cauHoi : cauhoi) {
//            if (cauHoi instanceof MultipleChoice && dem < n) {
//                dem++;
//                result.themCauHoi(cauHoi);
//            }
//        }
//
//        return result;
//    }
//
//    public CauHoi ngauNhienInComplete(int doKho) {
//        QuanLyCauHoi result = new QuanLyCauHoi();
//
//        for (CauHoi cauHoi : cauhoi) {
//            if (cauHoi instanceof InComplete && cauHoi.getCapDo() == doKho) {
//                result.themCauHoi(cauHoi);
//            }
//        }
//
//        int sl = (int) (Math.random() * result.getCauhoi().size());
//        return result.getCauhoi().get(sl);
//    }
//
//    public CauHoi ngauNhienConversation(int doKho) {
//        QuanLyCauHoi result = new QuanLyCauHoi();
//
//        for (CauHoi cauHoi : cauhoi) {
//            if (cauHoi instanceof Conversation && cauHoi.getCapDo() == doKho) {
//                result.themCauHoi(cauHoi);
//            }
//        }
//
//        int sl = (int) ((Math.random() * result.getCauhoi().size()));
//        return result.getCauhoi().get(sl);
//    }
//
//
//    public CauHoi ngauNhienMultipleChoice(int doKho) {
//        QuanLyCauHoi result = new QuanLyCauHoi();
//
//        for (CauHoi cauHoi : cauhoi) {
//            if (cauHoi instanceof MultipleChoice && cauHoi.getCapDo() == doKho) {
//                result.themCauHoi(cauHoi);
//            }
//        }
//
//        int sl = (int) ((Math.random() * (result.getCauhoi().size() - 0)) + 0);
//        return result.getCauhoi().get(sl);
//    }
//
//    public void hienThi() {
//        for (CauHoi cauHoi : cauhoi) {
//            cauHoi.hienThi();
//        }
//    }
    /**
     * @return the cauhoi
     */
    public List<CauHoi> getCauhoi() {
        return dsCauHoi;
    }

}

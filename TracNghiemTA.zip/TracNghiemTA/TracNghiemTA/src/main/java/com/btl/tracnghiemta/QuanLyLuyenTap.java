/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.btl.tracnghiemta;

import static com.btl.tracnghiemta.CauHinh.quanLyCauHoi;
import static com.btl.tracnghiemta.CauHinh.sc;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author thao trang
 */
public class QuanLyLuyenTap {
    //Conver và Inc
    public static void luyenTap(HocVien hocVien, String loai, String capDo) throws ClassNotFoundException {
        
        CauHoi cauHoi = quanLyCauHoi.randomCauHoi(loai, capDo);
        cauHoi.hienThiThongTin();
        int soCauDung = traLoiCauHoi(cauHoi.getdsCauHoi());
        LocalDate ngayLam = LocalDate.now();
        hocVien.getThanhTich().setSoLanLam(hocVien.getThanhTich().getSoLanLam() + 1);
        hocVien.getThanhTich().themDiem(Double.valueOf(soCauDung * (10 / cauHoi.getdsCauHoi().size())),ngayLam);
    }

    //radom ngẫu nhiên Muti
    public static void luyenTap(HocVien hocVien, String loai, int soLuong) throws ClassNotFoundException {
        List<CauHoi> temp = quanLyCauHoi.randomCauHoi(loai, soLuong);
        List<MultipleChoice> dsCauHoi = (List<MultipleChoice>) (Object) temp;
        int soCauDung = traLoiCauHoi(dsCauHoi);
        LocalDate ngayLam = LocalDate.now();
        hocVien.getThanhTich().setSoLanLam(hocVien.getThanhTich().getSoLanLam() + 1);
        hocVien.getThanhTich().themDiem(Double.valueOf(soCauDung * (10 / soLuong)), ngayLam);
    }

    private static int traLoiCauHoi(List<MultipleChoice> dsCauHoi) {
        List<Character> dsDapAn = new ArrayList<>();
        int soCauDung = 0;
        dsCauHoi.forEach(multipleChoice -> {
            multipleChoice.hienThiThongTin();
            multipleChoice.hienThiDsPhuongAn();
            System.out.print("- Chon dap an: ");
            dsDapAn.add(sc.next().toUpperCase().charAt(0));
        });
        System.out.println("------------------------");
        for (int i = 0; i < dsCauHoi.size(); i++) {
            MultipleChoice cauHoi = dsCauHoi.get(i);
            dsCauHoi.get(i).hienThiThongTin();
            int index = (dsDapAn.get(i)) - 'A';
            boolean dapAn = index >= 0 && index < cauHoi.getDsPhuongAn().size() && cauHoi.getDsPhuongAn().get(index).isDapAn();
            System.out.println("=> " + (dapAn ? "Dung" : "Sai"));
            soCauDung = (dapAn) ? soCauDung + 1 : soCauDung;
            System.out.println();
        }
        return soCauDung;
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.btl.tracnghiemta;

import static com.btl.tracnghiemta.CauHinh.f;
import static com.btl.tracnghiemta.CauHinh.sc;
import static com.btl.tracnghiemta.CauHinh.quanLyHocVien;
import static com.btl.tracnghiemta.CauHinh.quanLyCauHoi;
import static com.btl.tracnghiemta.CauHinh.quanLyDanhMuc;
import com.btl.tracnghiemta.CauHoi;
import com.btl.tracnghiemta.Conversation;
import com.btl.tracnghiemta.InComplete;
import com.btl.tracnghiemta.MultipleChoice;
import com.btl.tracnghiemta.PhuongAn;
import com.btl.tracnghiemta.QuanLyCauHoi;
import com.btl.tracnghiemta.DanhMuc;
import com.btl.tracnghiemta.QuanLyDanhMuc;
import com.btl.tracnghiemta.HocVien;
import com.btl.tracnghiemta.QuanLyHocVien;
import com.btl.tracnghiemta.QuanLyLuyenTap;
import com.btl.tracnghiemta.ThanhTich;
import java.io.FileNotFoundException;
import java.text.ParseException;
import java.util.Date;
import java.util.List;

/**
 *
 * @author thao trang
 */
public class Tester {

    public void Controller() throws FileNotFoundException, ParseException, ClassNotFoundException {
        QuanLyCauHoi quanLyCauHoi = new QuanLyCauHoi();

        int chonMenuChinh, chonQuanLyCauHoi, chonHocVien, chonCauHoi;
        String chonDangCauHoi;
        boolean mainThread, threadLamBai, threadCauHoi, threadHocVien;

        mainThread = true;

        //MENU CHÍNH
        while (mainThread) {
            threadHocVien = threadLamBai = threadCauHoi = true;
            menuChinh();
            chonMenuChinh = CauHinh.sc.nextInt();
            CauHinh.sc.nextLine();
            switch (chonMenuChinh) {

                case 1:
                    while (threadHocVien) {
                        menuHocVien();
                        chonHocVien = Integer.parseInt(CauHinh.sc.nextLine());

                        switch (chonHocVien) {
                            case 1:
                                System.out.print("\n--- NHAP THONG TIN HOC VIEN MOI --");
                                HocVien hv = new HocVien();
                                try {
                                    hv.nhapThongTin();
                                    hv.setThanhTich(new ThanhTich());
                                    quanLyHocVien.them(hv);
                                    System.out.println("=> THEM THANH VIEN THANH CONG!");
                                } catch (ParseException e) {
                                    System.out.println("Du lieu khong hop le!");
                                }
                                break;
                            case 2:
                                System.out.println("Danh sach hoc vien la: ");
                                quanLyHocVien.xuatDanhSachHv();
                                break;
                            case 3:
                                System.out.println("\nCap nhat thong tin hoc vien");
                                quanLyHocVien.xuatDanhSachHv();
                                System.out.print("Nhap ma hoc vien muon cap nhat: ");
                                int maHV = Integer.parseInt(sc.nextLine());
                                HocVien tv = quanLyHocVien.traCuu(maHV);
                                if (tv != null) {
                                    try {
                                        tv.nhapThongTin();
                                        System.out.println("Cap nhat thanh cong!");
                                    } catch (ParseException e) {
                                        System.out.println("Du lieu khong hop le!");
                                    }
                                } else {
                                    System.out.println("Khong tim thay hoc vien!");
                                }
                                break;
                            case 4:
                                System.out.println("\nXoa thong tin hoc vien");
                                quanLyHocVien.xuatDanhSachHv();
                                System.out.print("Nhap ma hoc vien muon xoa: ");
                                int maHVXoa = Integer.parseInt(CauHinh.sc.nextLine());
                                HocVien hvXoa = quanLyHocVien.traCuu(maHVXoa);
                                if (hvXoa != null) {
                                    quanLyHocVien.xoa(hvXoa);
                                    System.out.println("Xoa hoc vien thanh cong!");
                                } else {
                                    System.out.println("Khong tim thay hoc vien!");
                                }
                                break;
                            case 5:
                                System.out.print("Nhap ngay sinh can tra cuu: ");
                                try {
                                    Date ngaySinh = f.parse(CauHinh.sc.nextLine());
                                    System.out.println("---- DANH SACH HOC VIEN TRA CUU THEO NGAY SINH ----");
                                    List<HocVien> dsHocVienTheoNgaySinh = quanLyHocVien.traCuu(ngaySinh);
                                    quanLyHocVien.xuatDanhSachHv(dsHocVienTheoNgaySinh);
                                } catch (ParseException e) {
                                    System.out.println("Du lieu khong hop le!");
                                }
                                break;
                            case 6:
                                System.out.print("Nhap tu khoa can tra cuu (Ho Ten, gioi tinh, que quan): ");
                                String tuKhoa = CauHinh.sc.nextLine();
                                System.out.println("----- DANH SACH TRA CUU DUOC -----");
                                List<HocVien> dsTraCuu = quanLyHocVien.traCuu(tuKhoa);
                                quanLyHocVien.xuatDanhSachHv(dsTraCuu);
                                break;
                            case 0:
                                threadHocVien = false;
                                break;
                            default:
                                System.out.println("LOI!");
                                break;
                        }
                    }
                    break;
                //QUẢN LÝ CÂU HỎI
                case 2:
                    while (threadCauHoi) {
                        menuQuanLyCauHoi();
                        chonQuanLyCauHoi = Integer.parseInt(CauHinh.sc.nextLine());

                        switch (chonQuanLyCauHoi) {
                            case 1:
                                DanhMuc danhMuc = new DanhMuc();
                                danhMuc.nhapThongTinDm();
                                quanLyDanhMuc.themDanhMuc(danhMuc);
                                System.out.println("=> Them danh muc thanh cong!!!");
                                break;
                            case 2:
                                try {
                                System.out.print("Cau hoi thuoc danh muc: ");
                                DanhMuc dMuc = quanLyDanhMuc.traCuu(CauHinh.sc.nextLine());
                                if (dMuc == null) {
                                    throw new NullPointerException("Khong tim thay danh muc!!!");
                                }
                                menuChonCauHoi();
                                chonCauHoi = Integer.parseInt(CauHinh.sc.nextLine());
                                CauHoi cauHoi = null;
                                switch (chonCauHoi) {
                                    case 1:
                                        cauHoi = new MultipleChoice();
                                        cauHoi.nhapThongTinCauHoi();
                                        System.out.print("Nhap so luong phuong an: ");
                                        int soPhuongAn = Integer.parseInt(CauHinh.sc.nextLine());
                                        List<PhuongAn> dsPhuongAn = PhuongAn.nhapDsPhuongAn(soPhuongAn);
                                        ((MultipleChoice) cauHoi).setDsPhuongAn(dsPhuongAn);
                                        break;
                                    case 2:
                                        cauHoi = new InComplete();
                                        cauHoi.nhapThongTinCauHoi();
                                        System.out.print("Nhap so luong cau hoi: ");
                                        int soCH = Integer.parseInt(CauHinh.sc.nextLine());
                                        List<MultipleChoice> dsCauHoi = quanLyCauHoi.nhapDsMultipleChoice(soCH);
                                        ((InComplete) cauHoi).setDsCauHoi(dsCauHoi);
                                        break;
                                    case 3:
                                        cauHoi = new Conversation();
                                        cauHoi.nhapThongTinCauHoi();
                                        System.out.print("Nhap so luong cau hoi: ");
                                        int soConversation = Integer.parseInt(CauHinh.sc.nextLine());
                                        List<MultipleChoice> dsCH = QuanLyCauHoi.nhapDsMultipleChoice(soConversation);
                                        ((Conversation) cauHoi).setDsCauHoi(dsCH);
                                        break;
                                    case 0:
                                        threadLamBai = false;
                                        break;
                                    default:
                                        System.out.println("Du lieu khong hop le!!!");
                                        break;
                                }
                                if (cauHoi == null) {
                                    throw new NullPointerException("=> Khong tim thay cau hoi!!!");
                                }
                                dMuc.themCauHoi(cauHoi);
                                cauHoi.setDanhMuc(dMuc);
                                quanLyCauHoi.themCauHoi(cauHoi);
                                System.out.println("=> Then cau hoi thanh cong!!!");

                            } catch (Exception e) {
                                System.out.println("LOI!!!");
                                e.printStackTrace();
                            }
                            break;
                            case 3:
                                System.out.print("Ma cau hoi muon xoa: ");
                                int maCauHoi = Integer.parseInt(CauHinh.sc.nextLine());
                                CauHoi ques = quanLyCauHoi.traCuuTheoId(maCauHoi);
                                if (ques != null) {
                                    quanLyCauHoi.xoaCauHoi(ques);
                                    System.out.println("=> Xoa cau hoi thanh cong!!!");
                                } else {
                                    System.out.println("Khong tim thay cau hoi!!!");
                                }
                                break;
                            case 4:
                                System.out.println("---- DANH SACH CAU HOI ----");
                                quanLyCauHoi.hienThiDS();
                                break;
                            case 5:
                                System.out.print("\nNoi dung can tra cuu: ");
                                String nd = CauHinh.sc.nextLine();
                                System.out.println("---- DANH SACH TRA CUU THEO NOI DUNG ----");
                                List<CauHoi> dsND = quanLyCauHoi.traCuu(nd);
                                quanLyCauHoi.hienThiDS(dsND);
                                break;
                            case 6:
                                System.out.print("\nDanh muc can tra cuu: ");
                                String danhMucTraCuu = CauHinh.sc.nextLine();
                                DanhMuc dm = quanLyDanhMuc.traCuu(danhMucTraCuu);
                                if (dm != null) {
                                    System.out.println("---- DANH SACH TRA CUU THEO DANH MUC ----");
                                    dm.hienThiDsCauHoi();
                                } else {
                                    System.out.println("Khong tim thay danh muc!!!");
                                }
                                break;
                            case 7:
                                System.out.print("\nMuc do can tra cuu (De: 0, Trung Binh: 1, Kho: 2): ");
                                String doKhoTraCuu = CauHinh.sc.nextLine();
                                List<CauHoi> dsDoKho = quanLyCauHoi.traCuu(doKhoTraCuu);
                                quanLyCauHoi.hienThiDS(dsDoKho);
                                break;
                            case 0:
                                threadCauHoi = false;
                                break;
                            default:
                                System.out.println("LOI !!!");
                                break;
                        }
                    }
                    break;
                //LUYỆN TẬP
                case 3:
                    System.out.print("\n- Nhap ma thanh vien: ");
                    int ma = Integer.parseInt(sc.nextLine());
                    HocVien tv = quanLyHocVien.traCuu(ma);
                    if (tv != null) {
                        System.out.println("1. MultipleChoice");
                        System.out.println("2. InComplete");
                        System.out.println("3. Conversation");
                        System.out.print("- Chon loai cau hoi: ");
                        String chonLoai = CauHinh.sc.nextLine();
                        switch (chonLoai) {
                            case "1" -> {
                                System.out.print("- So luong cau hoi muon luyen tap: ");
                                int soLuong = Integer.parseInt(CauHinh.sc.nextLine());
                                QuanLyLuyenTap.luyenTap(tv, "com.btl.tracnghiemta.MultipleChoice", soLuong);
                            }
                            case "2" -> {
                                System.out.print("- Nhap muc do (De/Trung binh/Kho) de luyen tap: ");
//                                String mucDo = sc.nextLine();
                                int mucDo = Integer.parseInt(CauHinh.sc.nextLine());
                                QuanLyLuyenTap.luyenTap(tv, "com.btl.tracnghiemta.InComplete", mucDo);
                            }
                            case "3" -> {
                                System.out.print("- Nhap muc do (De/Trung binh/Kho) de luyen tap: ");
//                                String mucDo = sc.nextLine();
                                int mucDo = Integer.parseInt(CauHinh.sc.nextLine());
                                QuanLyLuyenTap.luyenTap(tv, "com.btl.tracnghiemta.Conversation", mucDo);
                            }
                            default ->
                                System.out.println("\n---- CHUC NANG HIEN CHUA CO ----");
                        }
                    } else {
                        System.out.println("\n----- KHONG TIM THAY HOC VIEN, VUI LONG ĐANG KY THANH VIEN -----");
                    }
                    break;

//                    while (threadLamBai) {
//                        System.out.print("Nhap ma thanh vien: ");
//                        int maHV = Integer.parseInt(CauHinh.sc.nextLine());
//                        HocVien hvien = quanLyHocVien.traCuu(maHV);
//                        menuChonCauHoi();
//                        chonDangCauHoi = Integer.parseInt(CauHinh.sc.nextLine());
//                        switch (chonDangCauHoi) {
//                            case 1:
//                                int soCauMultiple;
//                                System.out.print("So luong cau hoi muon lam: ");
//                                soCauMultiple = Integer.parseInt(CauHinh.sc.nextLine());
//
//                                if (soCauMultiple > quanLyCauHoi.soLuongMultipleChoice()) {
//                                    System.out.println("\nSo luong cau hoi co san khong du!!");
//                                } else {
//                                    QuanLyLuyenTap.luyenTap(hVien, "com.btl.tracnghiemta.MultipleChoice", soCauMultiple);
//                                }
//                                break;
//
//                            case 2:
//                                int doKho;
//                                System.out.print("Muc Do (De: 0, Trung Binh: 1, Kho: 2): ");
//                                doKho = Integer.parseInt(CauHinh.sc.nextLine());
//
//                                quanLyCauHoi.ngauNhienInComplete(doKho).hienThi();
//                                break;
//
//                            case 3:
//                                int dKho;
//                                System.out.print("Muc Do (De: 0, Trung Binh: 1, Kho: 2): ");
//                                dKho = Integer.parseInt(CauHinh.sc.nextLine());
//
//                                quanLyCauHoi.ngauNhienConversation(dKho).hienThi();
//                                break;
//
//                            case 0:
//                                threadLamBai = false;
//                                break;
//
//                            default:
//                                System.out.println("LOI !!!");
//                                break;
//                        }
//                    }
                case 4:
                    System.out.print("\n Nhap ma hoc vien: ");
                    int maHV = Integer.parseInt(CauHinh.sc.nextLine());
                    HocVien HV = quanLyHocVien.traCuu(maHV);
                    if (HV != null) {
                        quanLyHocVien.thongKe(HV);
                    } else {
                        System.out.println("=> Khong tim thay hoc vien");
                    }
                    break;
                case 0:
                    System.out.println("----- KET THUC CHUONG TRINH -----");
                    mainThread = false;
                    break;
                default:
                    System.out.println("LOI !!!");
                    break;
            }
        }
    }

    /**
     * Menu
     */
    public static void menuChinh() {
        System.out.println("\n\n----------- MENU ------------");
        System.out.println("1. Quan li hoc vien");
        System.out.println("2. Quan li cau hoi");
        System.out.println("3. Luyen Tap");
        System.out.println("4. Thong ke ket qua cua 1 hoc vien");
        System.out.println("0. Thoat!");
        System.out.println("-------------------------------");
        System.out.print("Chon chuc nang: ");
    }

    public static void menuHocVien() {
        System.out.println("\n\n----------- MENU QUAN LY HOC VIEN ------------");
        System.out.println("1. Them hoc vien moi");
        System.out.println("2. Xem danh sach hoc vien");
        System.out.println("3. Cap nhat thong tin hoc vien");
        System.out.println("4. Xoa thong tin hoc vien");
        System.out.println("5. Tra cuu hoc vien theo ngay sinh");
        System.out.println("6. Tra cuu hoc vien theo ten, gioi tinh, que quan");
        System.out.println("0. Tro lai menu chinh!");
        System.out.println("--------------------------------------------------");
        System.out.print("Chon chuc nang: ");
    }

    public static void menuQuanLyCauHoi() {
        System.out.println("\n\n----------- MENU QUAN LI CAU HOI ------------");
        System.out.println("1. Tao danh muc moi");
        System.out.println("2. Them cau hoi moi");
        System.out.println("3. Xoa cau hoi");
        System.out.println("4. Xuat danh sach cau hoi");
        System.out.println("5. Tra cuu theo noi dung");
        System.out.println("6. Tra cuu theo danh muc");
        System.out.println("7. Tra cuu theo muc do");
        System.out.println("0. Tro lai menu chinh!");
        System.out.println("---------------------------");
        System.out.print("Chon chuc nang: ");
    }

    public static void menuChonCauHoi() {
        System.out.println("\n\n----------- MENU CHON LOAI CAU HOI ------------");
        System.out.println("1. MultipleChoice");
        System.out.println("2. InComplete");
        System.out.println("3. Conversation");
        System.out.println("0. Tro lai menu chinh!");
        System.out.println("-------------- -------------");
        System.out.print("Chon chuc nang: ");
    }
}
